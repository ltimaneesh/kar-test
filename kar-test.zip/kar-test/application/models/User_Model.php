<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_Model extends CI_Model {
 public function __construct(){
    parent::__construct();
 }

 public function validateUser($user,$pass){
   $user_name = $this->security->xss_clean($user);
   $password= $this->security->xss_clean($pass);

   $this->db->where('user_name', $user_name);
   $this->db->where('password', md5($password));
   $this->db->where('status', 1);
  // $lastId= $this->db->insert_id();
   // Run the query
   $row = $this->db->get('users')->row();
   // Let's check if there are any results
   if(count($row) > 0)
   {
       return $row->id;
   }
   return false;
 }

 public function createandUpadteAccount($user_name,$account_type,$account_number=null){
    $user_name = $this->security->xss_clean($user_name);
    $account_type= $this->security->xss_clean($account_type);
  

    if(!empty($account_number)){
       
        $daata  =array(
            'user_name'=> $user_name,
            'account_type'=> $account_type,
        );
         $this->db->where('account_number', $account_number);
         $this->db->update('accounts',$daata);
         return $this->db->affected_rows();
    }else{
        $daata  =array(
            'user_name'=> $user_name,
            'account_type'=> $account_type,
            'account_balance'=>1000.00
        );
        $this->db->insert('accounts',$daata);
         return $this->db->insert_id();
    }
    return false;
 }

public function checkIfAltreadyExists($user_name,$account_type){
    $this->db->where('user_name', $user_name);
    $this->db->where('account_type', strtolower($account_type));
    $this->db->where('account_status',1);
    // Run the query
    $row = $this->db->get('accounts')->result();
    // Let's check if there are any results
    if(count($row) > 0)
    {
        return true;
    }
    return false;
}

 function validateAccount($acc){
    $this->db->where('account_number', $acc);
    $this->db->where('account_status',1);
    // Run the query
    $row = $this->db->get('accounts')->row();
    // Let's check if there are any results
    if(count($row) > 0)
    {
        return $row;
    }
    return false;
 }

 function getBankName(){
    $row= $this->db->get('banks')->row();
    return $row->name;
 }

 function getAccounts($id=""){
    if(!empty($id) && is_numeric($id)){
        $this->db->select('user_name,account_balance');
        $this->db->from('accounts');
        $this->db->where("account_number",$id);
        $this->db->where('account_status',1);
        return $this->db->get()->row(); 
    }
    $this->db->select('account_number');
    $this->db->from('accounts');
    $this->db->where('account_status',1);
    return $this->db->get()->result();
 }

 function getAccountsDetails($id){
    if(!empty($id) && is_numeric($id)){
        $this->db->select('user_name,account_type,account_balance');
        $this->db->from('accounts');
        $this->db->where("account_number",$id);
        $this->db->where('account_status',1);
        return $this->db->get()->row(); 
    }
    return false;
 }

  function depositAmt($to_acc,$amount){
        $this->db->where('account_number', $to_acc);
        $this->db->where('account_status',1);
        $row = $this->db->get('accounts')->row();
        if(count($row) > 0)
        {
           $currentbal = $row->account_balance;
           $accountNum = $row->account_number;
           $totalBalance = $currentbal + $amount  ;
           $this->db->where('account_number',$accountNum);
           $data = array(
            'account_balance'=> $totalBalance,
            'last_transaction_date'=> date('Y-m-d H:i:s')
           );
           $res= $this->db->update('accounts',$data);
           if($res){
            $status = "Success";
           }else{
            $status = "Failed";
           }
           $logData = array(
            'account_number'=> $accountNum,
            'trans_amount'=>$amount,
            'transaction_type'=> 'Deposit',
            'transaction_date'=> date('Y-m-d H:i:s'),
            'trans_status'=> $status
           );
           $this->logTrans($logData);
           return $res;
        }
    return false;
  }

  function withdrawAmt($fromAcc,$amount){
    $this->db->where('account_number', $fromAcc);
    $this->db->where('account_status',1);
        $row = $this->db->get('accounts')->row();
        if(count($row) > 0)
        {
           $currentbal = $row->account_balance;
           $accountNum = $row->account_number;
           $totalBalance = $currentbal - $amount  ;
           $this->db->where('account_number',$accountNum);
           $data = array(
            'account_balance'=> $totalBalance,
            'last_transaction_date'=> date('Y-m-d H:i:s')
           );
           $res= $this->db->update('accounts',$data);
           if($res){
            $status = "Success";
           }else{
            $status = "Failed";
           }
           $logData = array(
            'account_number'=> $accountNum,
            'trans_amount'=>$amount,
            'transaction_type'=> 'Withdrawal',
            'transaction_date'=> date('Y-m-d H:i:s'),
            'trans_status'=> $status
           );
           
           return $res;
        }
    return false;
}


public function doTransfer($from_acc,$to_acc,$amount){
    $this->db->where('account_number', $from_acc);
    $this->db->where('account_status',1);
    $row = $this->db->get('accounts')->row();
    
       $currentbal = $row->account_balance;
       $totalBalance = $currentbal - $amount  ;
      
       $data1 = array(
        'account_balance'=> $totalBalance,
        'last_transaction_date'=> date('Y-m-d H:i:s')
       );
       $this->db->where('account_number', $to_acc);
       $row1 = $this->db->get('accounts')->row();

       $currentbal1 = $row1->account_balance;
       $totalBalance1 = $currentbal1 + $amount  ;
       $data2 = array(
        'account_balance'=> $totalBalance1,
        'last_transaction_date'=> date('Y-m-d H:i:s')
       );
      
     
   $this->db->trans_start();
   $this->db->where('account_number',$from_acc);
   $this->db->update('accounts',$data1);

   $this->db->where('account_number',$to_acc);
   $this->db->update('accounts',$data2);
   $this->db->trans_complete();

   if( $this->db->trans_status() === FALSE){
    $this->db->trans_rollback();
    $logData = array(
        'account_number'=> $to_acc,
        'transaction_type'=> 'Transfer',
        'transaction_date'=> date('Y-m-d H:i:s'),
        'trans_status'=> 'Failed'
       );
    $this->logTrans($logData);
    return FALSE;
   }else{
    $this->db->trans_commit();
    $logData = array(
        'account_number'=> $to_acc,
        'trans_amount'=>$amount,
        'transaction_type'=> 'Transfer',
        'transaction_date'=> date('Y-m-d H:i:s'),
        'trans_status'=> 'Success'
       );
    $this->logTrans($logData);
    return TRUE;
   }
return false;
}


public function removeAccount($accountNum){
    if(!empty($accountNum)){
        $this->db->where('account_number',$accountNum);
        $this->db->update('accounts',array('account_status'=>0));
        return true;
    }
   return false;
}

public function logTrans($data){
    $this->db->insert('transaction_logs',$data);
}

}

?>