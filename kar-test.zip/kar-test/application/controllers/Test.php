<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Test extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
		$this->load->library('unit_test');
	}

	function index(){
		$test =  $this->user_model->getBankName();
		$expected_result =  trim($_POST['expected_result']); //"LTIMindtree";
		$test_name = "Unit test to get bank name";
		$test_note ="It will show test result either Passed or Failed.";
		echo $this->unit->run($test,$expected_result,$test_name,$test_note);
	}

	function validateAccountNumber($value){
		return preg_match("/^[0-9]+$/i", $value);
	}	

	function validateUsername($value){
		if (preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $value)) {
			return true;
		} else {
			return false;
		}
	}

	// Unit test for list of account and account details//
	
	function account($id=null){
		if(isset($id)){
			$expected_result = "is_object";
			$test_name = "Unit test for list the account details";
		}else{
			$expected_result = "is_array";
			$test_name = "Unit test for list the accounts";
		}
		
		$test = $this->user_model->getAccounts($id);
		$test_note ="It will show test result either Passed or Failed.";
		echo $this->unit->run($test,$expected_result,$test_name,$test_note);
	}

	function checking($id){
		
		$expected_result = "is_object";
		$test_name = "Unit test for checking the account type with details";
		$test = $this->user_model->getAccountsDetails($id,'checking');
		$test_note ="It will show test result either Passed or Failed.";
		echo $this->unit->run($test,$expected_result,$test_name,$test_note);
	}

	function createaccount(){
		$user_name = trim($_POST['user_name']);
		$account_type =trim($_POST['account_type']);
		$investment_account_type =trim($_POST['investment_account_type']);
		$expected_result = "is_true";
		$test_name = "Unit test for create new account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($user_name) || empty($account_type)){
			$test = false;
			echo  $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		if(strtolower($account_type) =="investment" && empty($investment_account_type)){
			$test = false;
			echo  $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		if(!in_array(strtolower($account_type),array('investment','checking'))){
			$test = false;
			echo  $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		if(strtolower($account_type) =="investment" && !in_array(strtolower($investment_account_type),array('individual','corporate'))){
			$test = false;
			echo  $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		if($this->user_model->checkIfAltreadyExists($user_name,$account_type,$investment_account_type)){
			$test = false;
			echo  $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		echo  $this->unit->run($test,$expected_result,$test_name,$test_note);
		 
	}

	function modifyaccount(){
		$user_name = trim($_POST['user_name']);
		$account_type =trim($_POST['account_type']);
		$investment_account_type =trim($_POST['investment_account_type']);
		$account_number =trim($_POST['account_number']);

		$expected_result = "is_true";
		$test_name = "Unit test for modify existing account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($user_name) || empty($account_type) || empty($account_number)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		if(strtolower($account_type) =="investment" && empty($investment_account_type)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		if(!in_array(strtolower($account_type),array('investment','checking'))){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		if(strtolower($account_type) =="investment" && !in_array(strtolower($investment_account_type),array('individual','corporate'))){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		if($this->user_model->checkIfAltreadyExists($user_name,$account_type,$investment_account_type)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		$status = $this->user_model->validateAccount($account_number);
		if(!$status){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note);die;
		}
		echo $this->unit->run($test,$expected_result,$test_name,$test_note);
		
	}

	function removeaccount(){
		$account_number =trim($_POST['account_number']);

		$expected_result = "is_true";
		$test_name = "Unit test for remove existing account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($account_number)){
				$test = false;
				echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$isValid  =$this->validateAccountNumber($account_number);
		if(!$isValid){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$status = $this->user_model->validateAccount($account_number);
		if(!$status){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		
	}

	function deposit(){
		$to_account =trim($_POST['to_account']);
		$amount  =trim($_POST['amount']);
		$expected_result = "is_true";
		$test_name = "Unit test for deposit money into an account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($to_account) || empty($amount)){
				$test = false;
				echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		if(!is_numeric($amount)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$isValid  =$this->validateAccountNumber($to_account);
		if(!$isValid){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$status = $this->user_model->validateAccount($to_account);
		if(!$status){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
	}

	function withdrawal(){
		$from_account =trim($_POST['from_account']);
		$amount  =trim($_POST['amount']);
		$expected_result = "is_true";
		$test_name = "Unit test for withdraw money from an account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($from_account) || empty($amount)){
				$test = false;
				echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		if(!is_numeric($amount)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$isValid  =$this->validateAccountNumber($from_account);
		if(!$isValid){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$status = $this->user_model->validateAccount($from_account);
		if(!$status){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		if(strtolower($status->account_type) =='individual' && $amount > 500){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
	}
	
	function transfer(){
		$from_account =trim($_POST['from_account']);
		$to_account =trim($_POST['to_account']);
		$amount  =trim($_POST['amount']);
		$expected_result = "is_true";
		$test_name = "Unit test for transfer money one account to other account";
		$test_note ="It will show test result either Passed or Failed.";
		$test = true;
		if(empty($from_account) || empty($to_account) || empty($amount)){
				$test = false;
				echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		if(!is_numeric($amount)){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}
		$isValid  =$this->validateAccountNumber($from_account);
		if(!$isValid){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		$isValid2  =$this->validateAccountNumber($to_account);
		if(!$isValid2){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		$status = $this->user_model->validateAccount($from_account);
		if(!$status){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		$status2 = $this->user_model->validateAccount($to_account);
		if(!$status2){
			$test = false;
			echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
		}

		echo $this->unit->run($test,$expected_result,$test_name,$test_note); die;
	}

}

