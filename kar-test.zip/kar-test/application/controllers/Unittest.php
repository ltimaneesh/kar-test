<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Unittest extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
	}

	function index($test,$expected_result,$test_name,$test_note=null){
		$this->load->library('unit_test');
		 echo $this->unit->run($test,$expected_result,$test_name,$test_note);
	}

	// Unit test for get bank name //
	function test_get_bank(){
		//$test =  $this->user_model->getAccounts($id);
		$test =  $this->user_model->getBankName();
		$expected_result = "LTIMindtree";
		$test_name = "Unit test to get bank name";
		$test_note ="Unit test to get bank name";
		$this->index($test,$expected_result,$test_name,$test_note);
	}

	// Unit test for get bank name //
	function unit_test2(){
		//$test =  $this->user_model->getAccounts($id);
		$test =  $this->user_model->getBankName();
		$expected_result = "LTIMindtee";
		$test_name = "Unit test to get bank name";
		$test_note ="Unit test to get bank name";
		$this->index($test,$expected_result,$test_name,$test_note);
	}
}
