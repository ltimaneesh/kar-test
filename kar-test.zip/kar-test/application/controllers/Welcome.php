<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Welcome extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
	}
	public function index()
	{
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			$res = $this->user_model->getBankName();
			$msg =array('status'=>'success',"bank_name"=>$res);
			$this->display_result_json($msg);
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
		
	}

	public function display_result_json($msg){
		echo json_encode($msg); die;
	}
}
