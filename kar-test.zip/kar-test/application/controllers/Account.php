<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Account extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
	}
	public function index()
	{
		//echo $this->uri->segment(2); die;
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			$id =null;
			if($this->uri->segment(2)){
				$id= $this->uri->segment(2);
				$this->intValidation($id);
			}
			$res = $this->user_model->getAccounts($id);
			if(count($res)){
				$msg =array('status'=>'success',"data"=>$res);
				$this->display_result_json($msg);
			}else{
				$msg =array('status'=>'failed',"msg"=>"No data found");
				$this->display_result_json($msg);
			}
			
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}

	public function intValidation($value,$fieldName ="Account Number"){
		if(is_numeric($value)){
			return;
		}else{
			$msg =array('status'=>'Failed',"msg"=>"$fieldName must be number value");
			$this->display_result_json($msg);
		}
	}

	public function checking($id=null){
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			if(empty($id)){
				$msg =array('status'=>'failed',"msg"=>"Account number must be passed in url");
				$this->display_result_json($msg);
			}
			if(!empty($id)){
				$this->intValidation($id);
				$res = $this->user_model->getAccountsDetails($id);
				if(count($res)){
					$msg =array('status'=>'success',"data"=>$res);
					$this->display_result_json($msg);
				}else{
					$msg =array('status'=>'failed',"msg"=>"Account number doesn't exists!");
					$this->display_result_json($msg);
				}
			}else{
					$msg =array('status'=>'failed',"msg"=>"Invalid request!!");
					$this->display_result_json($msg);
			}
			
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}



	public function deposit(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$to_acc =trim($_POST['to_account']);
			$amount  =trim($_POST['amount']);
			if(empty($to_acc) || empty($amount)){
				$msg =array('status'=>'failed',"msg"=>"to_account and amount fields are mandatory..");
				$this->display_result_json($msg);
			}
			$this->intValidation($to_acc,"To Account ");
			$accData = $this->user_model->validateAccount($to_acc);
			if(!empty($accData->account_number)){
				if(!empty($amount) && is_numeric($amount)){
					$res = $this->user_model->depositAmt($to_acc,$amount);
					if($res){
						$msg =array('status'=>'success',"msg"=>"Amount $amount deposited successfully");
						$this->display_result_json($msg);
					}else{
						$msg =array('status'=>'Failed',"msg"=>"Deposit failed. Please try again..");
						$this->display_result_json($msg);
					}
				}else{
					$msg =array('status'=>'Failed',"msg"=>"Amount must be a number!");
					$this->display_result_json($msg);
				}
				
			}else{
				$msg =array('status'=>'Failed',"msg"=>"Account number does not exists.");
				$this->display_result_json($msg);
			}
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
			
	}
	public function withdrawal(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$from_acc = trim($_POST['from_account']);
			$amount  =trim($_POST['amount']);
			if(empty($from_acc) || empty($amount)){
				$msg =array('status'=>'failed',"msg"=>"from_account and amount fields are mandatory..");
				$this->display_result_json($msg);
			}
			$this->intValidation($from_acc,"From Account");
			$accData = $this->user_model->validateAccount($from_acc);
			if(!empty($accData->account_number)){  
				if(!empty($amount) && is_numeric($amount)){
					$account_balance =  round($accData->account_balance);
					//echo $amount; die;
					if($amount < $account_balance){
						if(strtolower($accData->account_type) =='individual' && $amount > 500){
							$msg =array('status'=>'failed',"msg"=>"Maximum withdrawal limit is 500 in a transaction .");
							$this->display_result_json($msg);
						}
						$flag = $this->user_model->withdrawAmt($from_acc,$amount);
						if($flag){
							$msg =array('status'=>'success',"msg"=>"$amount withdrawan successfully.");
							$this->display_result_json($msg);
						}else{
							$msg =array('status'=>'Failed',"msg"=>"Withdrawal failed. Please try again..");
							$this->display_result_json($msg);
						}
					}else{
						$msg =array('status'=>'Failed',"msg"=>"Insufficient account balance.");
						$this->display_result_json($msg);
					}
				}else{
					$msg =array('status'=>'Failed',"msg"=>"Amount must be a number!");
					$this->display_result_json($msg);
				}
				
			}else{
				$msg =array('status'=>'Failed',"msg"=>"Account number does not exist.");
				$this->display_result_json($msg);
			}
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}


	public function transfer(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$from_acc = trim($_POST['from_account']);
			$to_acc =trim($_POST['to_account']);
			$amount  =trim($_POST['amount']);
			if(empty($from_acc) || empty($to_acc) || empty($amount)){
				$msg =array('status'=>'failed',"msg"=>"from_account , to_account and amount fields are mandatory..");
				$this->display_result_json($msg);
			}
			$this->intValidation($from_acc ,"From Account");
			$this->intValidation($to_acc,"To Account");
			$accData = $this->user_model->validateAccount($from_acc);
			if(!empty($accData->account_number)){  
				if(!empty($amount) && is_numeric($amount)){
					$acc_status = $this->user_model->validateAccount($to_acc);
					if(!empty($acc_status->account_number)){
						
						if(round($accData->account_balance) > $amount){
							$Transferflag = $this->user_model->doTransfer($from_acc,$to_acc,$amount);
							if($Transferflag){
								$msg =array('status'=>'success',"msg"=>"$amount Transfered  successfully.");
								$this->display_result_json($msg);
							}else{
								$msg =array('status'=>'Failed',"msg"=>"Transfer Failed");
								$this->display_result_json($msg);
							}
						}else{
							$msg =array('status'=>'Failed',"msg"=>"Insufficient account balance.");
							$this->display_result_json($msg);
						}
					}else{
						$msg =array('status'=>'Failed',"msg"=>"Account number does not exist in which amount has to be transfered!");
						$this->display_result_json($msg);
					}
				}else{
					$msg =array('status'=>'Failed',"msg"=>"Amount must be a number!");
					$this->display_result_json($msg);
				}
			}else{
				$msg =array('status'=>'Failed',"msg"=>"Account number does not exists.");
				$this->display_result_json($msg);
			}
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
		
	}

	// Create account //

	public function create(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$user_name = trim($_POST['user_name']);
			$account_type =trim($_POST['account_type']);
			if(empty($user_name) || empty($account_type)){
				$msg =array('status'=>'failed',"msg"=>"user_name and account_type fields are mandatory..");
				$this->display_result_json($msg);
			}
			if(!in_array(strtolower($account_type),array('individual','corporate'))){
				$msg =array('status'=>'failed',"msg"=>"Account type must be Individual or Corporate only.");
				$this->display_result_json($msg);
			}
			$exists_status = $this->user_model->checkIfAltreadyExists($user_name,$account_type);
			if($exists_status){
				$msg =array('status'=>'Failed',"msg"=>"$user_name already exists in database.");
				$this->display_result_json($msg);
			}
			$create_status = $this->user_model->createandUpadteAccount($user_name,$account_type);
			if($create_status){
				$msg =array('status'=>'success',"msg"=>" New account created successfully.");
				$this->display_result_json($msg);
			}else{
				$msg =array('status'=>'Failed',"msg"=>"Failed while creating account. try again!!");
			}

		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}

	public function modify(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$user_name = trim($_POST['user_name']);
			$account_type =trim($_POST['account_type']);
			$account_number =trim($_POST['account_number']);
			if(empty($user_name) || empty($account_type) || empty($account_number)){
				$msg =array('status'=>'failed',"msg"=>"user_name,account_number and account_type fields are mandatory..");
				$this->display_result_json($msg);
			}
			if(!in_array(strtolower($account_type),array('individual','corporate'))){
				$msg =array('status'=>'failed',"msg"=>"Account type must be Individual or Corporate only.");
				$this->display_result_json($msg);
			}
			$exists_status = $this->user_model->checkIfAltreadyExists($user_name,$account_type);
			if($exists_status){
				$msg =array('status'=>'Failed',"msg"=>"$user_name already exists in database.");
				$this->display_result_json($msg);
			}
			if(!empty($account_number)){
				$status = $this->user_model->validateAccount($account_number);
				if(!$status){
					$msg =array('status'=>'Failed',"msg"=>"Account number does not exists.");
					$this->display_result_json($msg);
				}
			}
			
			$modify_status = $this->user_model->createandUpadteAccount($user_name,$account_type,$account_number);
			if($modify_status){
				$msg =array('status'=>'success',"msg"=>" Account updated successfully.");
				$this->display_result_json($msg);
			}else{
				$msg =array('status'=>'Failed',"msg"=>"Failed while updating account. try again!!");
			}

		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}


	public function remove(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$account_number = trim($_POST['account_number']);
			if(empty($account_number)){
				$msg =array('status'=>'failed',"msg"=>"Account number is mandatory..");
				$this->display_result_json($msg);
			}

			$accData = $this->user_model->validateAccount($account_number);
			if(empty($accData->account_number)){
				$msg =array('status'=>'failed',"msg"=>"$account_number Account does not exists..");
				$this->display_result_json($msg);
			}
			$res = $this->user_model->removeAccount($account_number);
			if($res){
				$msg =array('status'=>'success',"msg"=>"Account removed successfully.");
				$this->display_result_json($msg);
			}else{
				$msg =array('status'=>'failed',"msg"=>"Failed while removing the account!");
				$this->display_result_json($msg);
			}
			
		}else{
			$msg =array('status'=>'Failed',"msg"=>"method not allowed!");
			$this->display_result_json($msg);
		}
	}
	public function display_result_json($msg){
		echo json_encode($msg); die;
	}
	

}
